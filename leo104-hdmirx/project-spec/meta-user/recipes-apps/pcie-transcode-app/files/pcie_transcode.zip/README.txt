PCIe application which communication between host to device and vice versa.
